// You are on vacation in our city and cannot bring many toys with you,
// or your child only plays with new toys for a few weeks.
// You can save a lot of money by simply renting toys from us!

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Toy {
    private final String toyId;
    private final String model;
    private final double pricePerDay;
    private boolean isAvailable;

    public Toy (String toyId, String model, double pricePerDay)
    {
        this.toyId = toyId;
        this.model = model;
        this.pricePerDay = pricePerDay;
        this.isAvailable = true;
    }
    public String getToyId() {
        return toyId;
    }
    public String getModel()
    {
        return model;
    }
    public double calculatePrice(int amountOfDays)
    {
        return pricePerDay*amountOfDays;
    }
    public boolean isAvailable() {
        return isAvailable;
    }
    public void rent(){
        isAvailable = false;
    }
    public void returnToy(){
        isAvailable = true;
    }
}
class Client {
    private final String clientId;
    private final String clientName;
    public Client (String clientId, String name)
    {
        this.clientId = clientId;
        this.clientName = name;
    }
    public String getClientId(){
        return clientId;
    }
    public String getClientName(){
        return clientName;
    }
}
class Rental{
    private final Toy toy;
    private final Client client;
    //private final int days;
    public Toy getToy() {
        return toy;
    }

    public Client getClient() {
        return client;
    }

    /*public int getDays() {
        return days;
    } */
    public Rental(Toy toy, Client client, int days)
    {
        this.toy = toy;
        this.client = client;
       // this.days = days;
    }
}
class ToyRentalSystem {
    /*public List<Toy> getToys()
    {
        return toys;
    } */
    private final List<Toy> toys;
    private final List<Client> clients;
    private final List<Rental> rentals;
    public ToyRentalSystem()
    {
        toys = new ArrayList<>();
        clients = new ArrayList<>();
        rentals = new ArrayList<>();
    }
    public void addToy(Toy toy) {
        toys.add(toy);
    }
    public void addClient(Client client)
    {
        clients.add(client);
    }
    public void rentToy(Toy toy, Client client, int days)
    {
        if (toy.isAvailable()) {
            toy.rent();
            rentals.add(new Rental(toy, client, days));
        } else {
            System.out.println("This toy cannot be rented now.");
        }
    }
    public void returnToy(Toy toy)
    {
        toy.returnToy();
        Rental rentalToRemove = null;
        for (Rental rental : rentals)
        {
            if (rental.getToy() == toy)
            {
                rentalToRemove = rental;
                break;
            }
        }
        if (rentalToRemove != null)
        {
            rentals.remove(rentalToRemove);
        } else
        {
            System.out.println("This Toy was not rented.");
        }
    }
    public void toysList() {
        Scanner scanner = new Scanner(System.in);

        while (true)
        {
            System.out.println(" ");
            System.out.println("* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *");
            System.out.println("* Dear client, we are glad to make you and your kids happier.     *");
            System.out.println("* Please, choose what you would like to do today.                 *");
            System.out.println("* Press 1 to rent a toy.                                          *");
            System.out.println("* Press 2 to return a toy.                                        *");
            System.out.println("* Press 3 to exit.                                                *");
            System.out.println("* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *");

            String input = scanner.nextLine();
            int number = 0;
            try
            {
               number = Integer.parseInt(input);
            }
            catch(Exception ex)
            {
                System.out.println(ex.getMessage());
            }
            if (number == 1)
            {
                System.out.println("What a good idea!\nPlease, enter your name: ");
                String clientName = scanner.nextLine();

                System.out.println("\nDear " + clientName + ", the toys that can be rented today are: ");
                for (Toy toy : toys)
                {
                    if (toy.isAvailable())
                    {
                        System.out.println(toy.getModel());
                    }
                }

                System.out.println("\nWhat toy would you like to have?:");
                input = scanner.nextLine();
                Toy chosenToy = null;

                for (Toy toy : toys)
                {
                    if (toy.getModel().equals(input))
                    {
                        chosenToy = toy;
                    }
                }
               if(chosenToy == null)
               {
                   System.out.println("Error: There is no toy with the name: " + input);
                   continue;
               }

                System.out.println("\nHow many days does your kid want to play with the toy? \nPlease, enter a number from 1 to 30");

                int rentalDays = 0;
                input = scanner.nextLine();
                try
                {
                    rentalDays = Integer.parseInt(input);
                }
                catch (Exception ex)
                {
                    System.out.println(ex.getMessage());
                }

               Client newClient = new Client(" " + (clients.size() + 1), clientName);
                this.addClient(newClient);

                for (Toy toy : toys)
                {
                    if (toy.getToyId().equals(chosenToy.getToyId()) && toy.isAvailable())
                    {
                        chosenToy = toy;
                        break;
                    }
                }
                if (chosenToy != null)
                {
                    double totalPrice = chosenToy.calculatePrice(rentalDays);
                    System.out.println(" ");
                    System.out.println("Here is the details of your rent.");
                    System.out.println("Your name         - " + newClient.getClientName());
                    System.out.println("Your client ID    - " + newClient.getClientId());
                    System.out.println("Your toy          - " + chosenToy.getModel());
                    System.out.println("Toy's ID          - " + chosenToy.getToyId());
                    System.out.println("The amount of day - " + rentalDays);
                    System.out.println("Total price       - " + totalPrice + " Euro");
                    System.out.println(" ");
                    System.out.println("Would you like to rent the chosen toy? (Y/N)");
                    String confirmation = scanner.nextLine();
                    if (confirmation.equalsIgnoreCase("Y"))
                    {
                        rentToy(chosenToy, newClient, rentalDays);
                        System.out.println("The toy " + chosenToy.getModel() + " is waiting for you at our office.");
                        System.out.println("Don't forget to bring money!");
                    }
                    else
                    {
                        System.out.println("Ooo no! Your kid won't get any toy.");
                    }
                }
            }
                else if (number == 2)
                {
                    System.out.println("It's time to bring the toy back.");
                    System.out.println("Please, try to remember the toy's ID");
                    System.out.println("Toy's ID - ");
                    String toyId = scanner.nextLine();
                    Toy toyBack = null;
                    for (Toy toy : toys)
                    {
                        if (toy.getToyId().equals(toyId) && !toy.isAvailable())
                        {
                            toyBack = toy;
                            break;
                        }
                    }
                    if (toyBack != null)
                    {
                        Client client = null;
                        for (Rental rental : rentals)
                        {
                            if (rental.getToy() == toyBack)
                            {
                                client = rental.getClient();
                                break;
                            }
                        }
                        if (client != null)
                        {
                            returnToy(toyBack);
                            System.out.println(client.getClientName() + ", thank you for bringing the toy back!");
                        }
                        else
                        {
                            System.out.println("You didn't rent any toy.");
                        }
                    }
                    else
                    {
                        System.out.println("You entered a wrong toy's ID");
                    }
                }
                else if (number == 3)
                {
                     break;
                }
            System.out.println("\nHave a nice day :-)\n\n");
        }
    }
}
    public class Main {
        public static void main(String[] args) {
            ToyRentalSystem rentalSystem = new ToyRentalSystem();
            Toy toy1 = new Toy("A001", "Doll Barbie", 1.25);
            Toy toy2 = new Toy("A002", "Doll Wendy", 1.25);
            Toy toy3 = new Toy("A003", "Car Jeep", 1.50);
            Toy toy4 = new Toy("A004", "Car BMW", 1.50);
            Toy toy5 = new Toy("A005", "Big ball", 1.00);
            Toy toy6 = new Toy("A006", "Small ball", 0.50);
            Toy toy7 = new Toy("A007", "Kitchen", 2.75);
            Toy toy8 = new Toy("A008", "Railway station", 2.75);
            Toy toy9 = new Toy("A009", "Doctor set", 2.25);
            Toy toy10 = new Toy("A010", "Policeman set", 2.25);

            rentalSystem.addToy(toy1);
            rentalSystem.addToy(toy2);
            rentalSystem.addToy(toy3);
            rentalSystem.addToy(toy4);
            rentalSystem.addToy(toy5);
            rentalSystem.addToy(toy6);
            rentalSystem.addToy(toy7);
            rentalSystem.addToy(toy8);
            rentalSystem.addToy(toy9);
            rentalSystem.addToy(toy10);

            rentalSystem.toysList();
        }
    }


